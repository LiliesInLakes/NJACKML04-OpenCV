"""
Webots controller: camera line follower for the e-puck robot.
Paste this into the controller file Webots creates for you
(Wizards > New Robot Controller > Python).

Needs OpenCV + numpy in the Python that Webots uses.
"""
from controller import Robot
import numpy as np
import cv2

# =====================================================
# SETTINGS
# =====================================================
BASE_SPEED = 3.0      # wheel speed (e-puck max is 6.28 rad/s)
KP = 0.05              # steering strength (bigger = turns harder)
MAX_SPEED = 6.28      # e-puck motor limit
BAND_TOP = 0.65       # look at rows from 65% down the image ...
BAND_BOTTOM = 0.85    # ... to 85% down (lower in the image = closer to the robot)
SHOW_WINDOW = True    # show what the robot sees

# =====================================================
# SET UP THE ROBOT
# =====================================================
robot = Robot()
timestep = int(robot.getBasicTimeStep())

camera = robot.getDevice("camera")
camera.enable(timestep)
WIDTH = camera.getWidth()
HEIGHT = camera.getHeight()

left_motor = robot.getDevice("left wheel motor")
right_motor = robot.getDevice("right wheel motor")
left_motor.setPosition(float("inf"))    # inf = "spin forever" (speed control mode)
right_motor.setPosition(float("inf"))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)


# =====================================================
# SEE + DECIDE: same idea as the 2D simulator
# =====================================================
def find_line_error(frame_bgra):
    gray = cv2.cvtColor(frame_bgra, cv2.COLOR_BGRA2GRAY)
    top = int(HEIGHT * BAND_TOP)
    bottom = int(HEIGHT * BAND_BOTTOM)
    band = gray[top:bottom, :]
    dark = band < 100                       # black pixels = the line
    columns = np.where(dark)[1]             # x-positions of the black pixels
    if len(columns) == 0:
        return None                         # no line seen
    line_x = columns.mean()
    return line_x - WIDTH / 2               # negative = line on left, positive = right


def clamp(v):
    return max(-MAX_SPEED, min(MAX_SPEED, v))


# =====================================================
# MAIN LOOP
# =====================================================
last_error = 0.0

while robot.step(timestep) != -1:
    # SEE: Webots gives raw bytes in BGRA order -> turn into a (height, width, 4) array
    raw = camera.getImage()
    frame = np.frombuffer(raw, dtype=np.uint8).reshape((HEIGHT, WIDTH, 4))

    # DECIDE
    error = find_line_error(frame)
    if error is None:
        error = last_error                  # lost the line: keep the last steering
    last_error = error
    turn = KP * error

    # MOVE: line on the right (error > 0) -> left wheel faster -> robot turns right
    left_motor.setVelocity(clamp(BASE_SPEED + turn))
    right_motor.setVelocity(clamp(BASE_SPEED - turn))

    # (optional) show the camera picture on screen
    if SHOW_WINDOW:
        img = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        img = cv2.resize(img, None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST)
        cv2.imshow("e-puck camera", img)
        cv2.waitKey(1)